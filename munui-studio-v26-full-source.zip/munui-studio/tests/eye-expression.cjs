const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');const html=fs.readFileSync(path.join(__dirname,'../dist/index.html'),'utf8'),script=html.match(/<script>([\s\S]*)<\/script>/)[1].replace(/render\(\);\s*$/,'');const context={assert,document:{getElementById(){return {style:{},addEventListener(){}}},addEventListener(){}},localStorage:{getItem(){return null}}};vm.createContext(context);vm.runInContext(script,context);
vm.runInContext(`
const base={...defaults,shape:'eye',eyePupilCount:4,eyePupilStyle:'sparkle',eyePupilLayout:'concentric'};
for(const eyeSmile of [-100,0,55,100])for(const eyeClosure of [0,25,75,99,100])for(const eyeAngular of [0,60,100]){
 const model={...base,eyeSmile,eyeClosure,eyeAngular},out=eyeGeometry(model);assert.ok(!/NaN|Infinity|undefined/.test(out));assert.deepEqual(clean(JSON.parse(JSON.stringify(model))),model);
 for(const x of [-100,-50,0,50,100]){const lids=eyeLidBounds(model,x);assert.ok(lids.top<=lids.bottom+1e-8);assert.ok(Math.abs((lids.top+lids.bottom)/2-eyeArcOffset(model,x))<1e-8);assert.ok(Math.abs(lids.bottom-lids.top-2*eyeEnvelope(model,x)*(1-eyeClosure/100))<1e-8);}
 if(eyeClosure===100){assert.ok(out.includes('data-eye-closed'));assert.ok(!out.includes('data-eye-pupil'));assert.ok(!out.includes('data-nature-paint="iris"'));assert.ok(!out.includes('clipPath'));assert.ok(!eyeOutlinePath(model).includes('Z'));}
 else if(eyeClosure||eyeSmile){assert.ok(out.includes('clip-path="url(#eyeClip)"'));assert.ok(out.includes('data-nature-paint="eye-mask"'));assert.ok(out.includes('d="'+eyeOutlinePath(model)+'" fill="#ffffff"'));}
 else assert.ok(!out.includes('eyeClip'),'neutral projects preserve unmasked geometry');
}
for(const viewScope of ['scene','motif'])for(const eyeClosure of [60,100]){
 const model={...base,eyeSmile:65,eyeClosure,viewScope,viewX:55,viewY:-30,viewDistance:300,swirlAngle:30,mode:'radial',count:3,itemScale:25,pressureOn:true,lineFeel:'ink'},out=svg(model);assert.ok(!/NaN|Infinity|undefined/.test(out));
 const ids=[...out.matchAll(/\\bid="([^"]+)"/g)].map(m=>m[1]);assert.equal(new Set(ids).size,ids.length);for(const m of out.matchAll(/(?:url\\(#|href="#)([^)"]+)/g))assert.ok(ids.includes(m[1]),'missing '+m[1]);
 if(eyeClosure===60)assert.ok(ids.some(id=>id.startsWith('eyeClip')));
}
for(const k of ['eyeSmile','eyeClosure'])assert.ok(shapeKeys.eye.includes(k));
const bounded=clean({...base,eyeSmile:999,eyeClosure:-999});assert.equal(bounded.eyeSmile,100);assert.equal(bounded.eyeClosure,0);
const closed={...base,eyeClosure:100,eyeSmile:65,strokeOn:false};assert.ok(source(closed).includes('stroke="'+closed.color+'"'),'closed stroke falls back to fill color');
`,context);console.log('PASS: 60 eyelid expressions, real vector clipping, complete closure without iris/pupil, neutral compatibility, matching bounds, unique repeated/XYZ clips, pressure/JSON/reset');

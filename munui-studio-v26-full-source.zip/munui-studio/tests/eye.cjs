const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');const html=fs.readFileSync(path.join(__dirname,'../dist/index.html'),'utf8'),script=html.match(/<script>([\s\S]*)<\/script>/)[1].replace(/render\(\);\s*$/,'');const context={assert,document:{getElementById(){return {style:{},addEventListener(){}}},addEventListener(){}},localStorage:{getItem(){return null}}};vm.createContext(context);vm.runInContext(script,context);
vm.runInContext(`
assert.ok(!Object.hasOwn(defaults,'eyeLashes'));assert.ok(!shapeKeys.eye.includes('eyeLashes'));assert.equal(clean({...defaults,eyePupilStyle:'star'}).eyePupilStyle,'sparkle');
for(const eyeAngular of [0,50,100])for(const eyeOpening of [15,80])for(const eyeGaze of [-60,0,60]){
 const s=clean({...defaults,shape:'eye',eyeAngular,eyeOpening,eyeGaze,eyeIrisSize:48}),R=eyeIrisRadius(s);
 for(let i=0;i<128;i++){const a=i*Math.PI/64,x=eyeGaze+R*Math.cos(a),y=R*Math.sin(a);assert.ok(Math.abs(y)<=eyeEnvelope(s,x)+1e-5,'iris must stay within angular eyelids');}
 for(const eyePupilLayout of ['linear','radial'])for(const eyePupilCount of [1,2,5,9])for(const eyePupilStyle of ['round','slit','sparkle'])for(const eyePupilSpacing of [20,90]){
  const p={...s,eyePupilLayout,eyePupilCount,eyePupilStyle,eyePupilSpacing,eyePupilSize:85,eyePupilAngle:37},points=eyePupilPlacements(p,R);assert.equal(points.length,eyePupilCount);
  for(const [i,a] of points.entries()){
   assert.ok(Math.hypot(a.x-eyeGaze,a.y)+a.r<=R+1e-8,'pupil must stay within iris');
   for(const b of points.slice(i+1))assert.ok(Math.hypot(a.x-b.x,a.y-b.y)+1e-8>=a.r+b.r,'pupils must not overlap');
  }
  const raw=eyeGeometry(p);assert.equal((raw.match(/data-eye-pupil=/g)||[]).length,eyePupilCount);assert.ok(!raw.includes('lashes'));assert.ok(!/NaN|Infinity|undefined/.test(raw));
 }
}
const model={...defaults,shape:'eye',eyeAngular:85,eyePupilCount:5,eyePupilStyle:'sparkle',eyePupilLayout:'radial'};
for(const [key,value] of [['eyeAngular',20],['eyePupilCount',3],['eyePupilLayout','linear'],['eyePupilSpacing',80],['eyePupilAngle',30]])assert.notEqual(eyeGeometry(model),eyeGeometry({...model,[key]:value}),key);
for(const key of ['eyeAngular','eyePupilCount','eyePupilLayout','eyePupilSpacing','eyePupilAngle'])assert.ok(shapeKeys.eye.includes(key));
const bounded=clean({...model,eyePupilCount:999,eyeAngular:-10,eyePupilSpacing:0,eyePupilAngle:999,eyePupilLayout:'bad'});assert.equal(bounded.eyePupilCount,9);assert.equal(bounded.eyeAngular,0);assert.equal(bounded.eyePupilSpacing,20);assert.equal(bounded.eyePupilAngle,180);assert.equal(bounded.eyePupilLayout,'concentric');assert.deepEqual(clean(JSON.parse(JSON.stringify(model))),model);
for(const viewScope of ['scene','motif']){const out=svg({...model,viewScope,viewX:55,viewY:-25,viewDistance:300,swirlAngle:25,mode:'radial',count:3,itemScale:25,pressureOn:true,lineFeel:'ink'});assert.ok(!/NaN|Infinity|undefined/.test(out));assert.ok(out.includes('data-eye-pupil='));}
`,context);console.log('PASS: angular eyelids/iris containment, 864 pupil combinations, non-overlap/containment/count, sparkle migration, lash removal, reset/JSON, XYZ/swirl/pressure/repeat export');

// Deterministic flower controls, concave boundary clipping, painting, and export.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path'),cp=require('node:child_process');
const html=fs.readFileSync(path.join(__dirname,'../dist/index.html'),'utf8');
const script=html.match(/<script>([\s\S]*)<\/script>/)[1].replace(/render\(\);\s*$/,'');
const context={assert,document:{getElementById(){return {style:{},addEventListener(){}}},addEventListener(){}},localStorage:{getItem(){return null}}};
vm.createContext(context);vm.runInContext(script,context);
// Legacy flowers retain their exact paths with new controls at neutral defaults.
const oldHtml=cp.execFileSync('git',['show','af468900dbf76a00a2ef3423e708d724f03c1ec8:dist/index.html'],{cwd:path.join(__dirname,'..'),encoding:'utf8',maxBuffer:4e6});
const oldContext={...context};vm.createContext(oldContext);vm.runInContext(oldHtml.match(/<script>([\s\S]*)<\/script>/)[1].replace(/render\(\);\s*$/,''),oldContext);
for(const flowerPetalTip of ['round','point','notched'])for(const flowerLayers of [1,4]){const expr=`flowerGeometry({...defaults,shape:'flower',flowerPetalTip:${JSON.stringify(flowerPetalTip)},flowerLayers:${flowerLayers}})`;assert.equal(vm.runInContext(expr,context),vm.runInContext(expr,oldContext));}
vm.runInContext(`
const flower={...defaults,shape:'flower'};
for(const flowerCenterShape of ['circle','square','triangle','star','polygon'])for(let mask=1;mask<16;mask++){
 const s=clean({...flower,flowerCenterShape,flowerCenterSize:45,flowerGridOn:!!(mask&1),flowerRadialOn:!!(mask&2),flowerRingsOn:!!(mask&4),flowerDotsOn:!!(mask&8)}),out=geometry(s);
 assert.ok(!/NaN|Infinity|undefined/.test(out));assert.equal(out,geometry(clean(JSON.parse(JSON.stringify(s)))));
 assert.equal((out.match(/data-flower-pattern=/g)||[]).length,mask.toString(2).replace(/0/g,'').length);
 const boundary=flowerCenterBoundary(s);for(let i=-3;i<=3;i++){const a=[-70,i*10],b=[70,i*10],d=flowerClipLine(a,b,boundary);for(const c of samplePath(d)){if(c.type==='Z')continue;const [x,y]=c.p;assert.ok(x>=-70&&x<=70&&y>=-31&&y<=31)}}
}
// A concave star must produce separated line intervals rather than bridge its notches.
const star={...flower,flowerCenterShape:'star',flowerCenterSize:45,flowerCenterStarRatio:20},boundary=flowerCenterBoundary(star);let separated=false;
for(let y=-40;y<=40;y+=2){const d=flowerClipLine([-60,y],[60,y],boundary);const parts=[...d.matchAll(/M([^L]+)L([^M]+)/g)];if(parts.length>1)separated=true;for(const part of parts){const a=part[1].split(',').map(Number),b=part[2].split(',').map(Number);for(let t=.01;t<.99;t+=.11)assert.ok(flowerInside([a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t],boundary),JSON.stringify({y,a,b,t}));}}assert.ok(separated);
const patterned={...flower,flowerCenterShape:'polygon',flowerGridOn:true,flowerRadialOn:true,flowerRingsOn:true,flowerDotsOn:true};
for(const [key,value] of [['flowerOverlap',75],['flowerPetals',48],['flowerLayers',8],['flowerPetalLength',140],['flowerPetalTip','flat'],['flowerCenterShape','triangle'],['flowerCenterSides',9],['flowerCenterRotation',30],['flowerGridCount',16],['flowerRadialCount',48],['flowerRingCount',10],['flowerDotCount',300],['flowerDotSize',2.3],['flowerDotLayout','grid'],['flowerPatternAngle',35],['flowerPatternWidth',2],['flowerPatternOpacity',40],['flowerPatternColor','#ff0000']])assert.notEqual(geometry(patterned),geometry({...patterned,[key]:value}),key);
assert.equal((flowerGeometry({...flower,flowerPetals:48,flowerLayers:8}).match(/data-flower-petal=/g)||[]).length,384);
assert.ok(!flowerCenterPatterns({...patterned,flowerCenterOn:false}));
const petals=s=>flowerGeometry(s).split('<path data-flower-center=')[0];assert.equal(petals(patterned),petals({...patterned,flowerGridCount:20,flowerPatternColor:'#ff0000'}));
for(const key of Object.keys(defaults).filter(k=>k.startsWith('flower')))assert.ok(shapeKeys.flower.includes(key),'reset includes '+key);
const bounded=clean({...flower,flowerPetals:999,flowerLayers:99,flowerOverlap:-20,flowerCenterSides:99,flowerCenterPoints:3.5,flowerDotCount:9999,flowerPatternColor:'bad',flowerCenterShape:'bad',flowerDotLayout:'bad'});assert.equal(bounded.flowerPetals,48);assert.equal(bounded.flowerLayers,8);assert.equal(bounded.flowerOverlap,0);assert.equal(bounded.flowerCenterSides,16);assert.equal(bounded.flowerCenterPoints,4);assert.equal(bounded.flowerDotCount,400);assert.equal(bounded.flowerPatternColor,defaults.flowerPatternColor);assert.equal(bounded.flowerCenterShape,'circle');assert.equal(bounded.flowerDotLayout,'sunflower');
for(const flowerCenterShape of ['circle','star']){
 const s={...patterned,flowerCenterShape,viewX:45,viewY:-25,viewDistance:300,swirlAngle:20,mode:'radial',count:3,itemScale:25,flowerPatternColor:'#ff0000'};
 const output=svg(s);assert.ok(!/NaN|Infinity|undefined/.test(output));assert.ok(output.includes('data-flower-pattern="grid"'));assert.ok(output.includes('stroke="#ff0000"'));
 const raw=source({...s,viewX:0,viewY:0,swirlAngle:0,strokeOn:false,fill:'none'});assert.ok(raw.includes('data-flower-pattern'));assert.ok(raw.includes('stroke="#ff0000"'));assert.ok(raw.lastIndexOf('data-flower-pattern')>raw.lastIndexOf('data-flower-center'));
}
`,context);
console.log('PASS: flower shapes, 75 pattern combinations, concave clipping, independent petals/layers/overlap/tips, bounds/reset/JSON, legacy path compatibility, XYZ/swirl/repeat/SVG painting');

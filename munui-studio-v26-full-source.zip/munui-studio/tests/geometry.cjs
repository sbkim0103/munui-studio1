// Run with: node tests/geometry.cjs
// Exercise the mathematical model without a browser or external packages.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
const html = fs.readFileSync(path.join(__dirname, '../dist/index.html'), 'utf8');
const code = html.match(/<script>([\s\S]*)<\/script>/)[1].replace(/render\(\);\s*$/, '');
const nodes = {};
const context = {
  assert,
  hashText: value => require('node:crypto').createHash('sha256').update(value).digest('hex'),
  document: { getElementById(id) { return nodes[id] ??= { style: {}, addEventListener() {} }; }, addEventListener() {} },
  localStorage: { getItem() { return null; } },
};
vm.createContext(context);
vm.runInContext(code, context);
vm.runInContext(`
  // Older v1 files receive new defaults while keeping their previous choices.
  const legacy = clean({version:1,shape:'leaf',mode:'radial',count:12,color:'#123456'});
  assert.equal(legacy.mode,'radial'); assert.equal(legacy.count,12);
  assert.equal(legacy.color,'#123456'); assert.equal(legacy.fractalDepth,3);
  assert.equal(legacy.leafBend,0); assert.equal(legacy.halftoneSpacing,9);
  const loaded=clean(JSON.parse(JSON.stringify({...defaults,shape:'heart',heartDepth:74,texture:'halftone',halftoneSize:4.5,mode:'spiral',layoutTurns:3.25})));
  assert.equal(loaded.heartDepth,74); assert.equal(loaded.layoutTurns,3.25); assert.equal(loaded.halftoneSize,4.5);
  assert.throws(()=>clean({version:999}));

  // Every shape and every arrangement produces finite values and resolvable references.
  for(const shape of Object.keys(shapeNames)) for(const mode of Object.keys(modeNames)) {
    const model=clean({...defaults,shape,mode,fill:'gold',texture:'halftone'});
    const out=svg(model);
    assert.ok(!/NaN|undefined|Infinity/.test(out),shape+' '+mode);
    const ids=[...out.matchAll(/\\bid="([^"]+)"/g)].map(m=>m[1]);
    assert.equal(new Set(ids).size,ids.length);
    for(const match of out.matchAll(/(?:url\\(#|href="#)([^)"]+)/g)) assert.ok(ids.includes(match[1]),'unresolved '+match[1]);
    for(const p of placements(model)) for(const v of Object.values(p)) assert.ok(Number.isFinite(v));
  }
  for(const [shape,spec] of Object.entries(shapeSpecs)) for(const [key,,min,max] of spec) {
    const before=geometry(clean({...defaults,shape,cloudLayers:key==='cloudLayerGap'?3:defaults.cloudLayers,[key]:min}));
    const after=geometry(clean({...defaults,shape,cloudLayers:key==='cloudLayerGap'?3:defaults.cloudLayers,[key]:key==='oceanPhase'?180:max}));
    assert.ok(!/NaN|undefined|Infinity/.test(before+after),shape+' '+key);
    assert.notEqual(before,after,shape+' '+key+' should affect geometry');
  }

  for(const shape of openShapes) {
    const model=clean({...defaults,shape,pressureOn:true,strokeWidth:8});
    const pts=linePoints(model), ribbon=pressureOutline(model,pts);
    assert.ok(ribbon.endsWith('Z')); assert.ok(!/NaN|Infinity/.test(ribbon));
    assert.notEqual(source(model),source({...model,pressureOn:false}));
    for(const k of ['pressureStart','pressureMiddle','pressureEnd','pressurePeak','pressureSmooth']) {
      assert.notEqual(pressureOutline({...model,[k]:k==='pressurePeak'?80:0},pts),ribbon,k);
    }
    const out=svg({...model,mode:'fractal',fractalBranches:4,fractalDepth:4});
    assert.ok(!/NaN|undefined|Infinity/.test(out));
    const restored=clean(JSON.parse(JSON.stringify(model)));
    assert.equal(source(restored),source(model));
  }
  assert.equal(clean({version:1}).pressureOn,false);
  for(const shape of [...leafShapes,'fern']) for(const leafArrangement of ['single','paired','alternate']) {
    const model=clean({...defaults,shape,leafArrangement,leafRightScale:70,leafStagger:65});
    const out=svg(model); assert.ok(!/NaN|undefined|Infinity/.test(out));
    assert.equal(geometry(clean(JSON.parse(JSON.stringify(model)))),geometry(model));
    if(leafArrangement!=='single')assert.notEqual(geometry(model),geometry({...model,leafRightScale:110}));
  }
  for(const [crossTip] of tipOptions) {
    const model=clean({...defaults,shape:'cross',crossTip});
    assert.ok(!/NaN|undefined|Infinity/.test(svg(model)));
    if(crossTip!=='none')assert.notEqual(geometry(model),geometry({...model,crossTipSize:60}));
    if(['fork','trident'].includes(crossTip))assert.notEqual(geometry(model),geometry({...model,crossSplitDepth:10}));
    const separate={...model,crossTipSeparate:true,crossTipTop:'circle',crossTipRight:'fork',crossTipBottom:'diamond',crossTipLeft:'trident'};
    assert.ok(!/NaN|undefined|Infinity/.test(svg(separate)));
    assert.equal(geometry(clean(JSON.parse(JSON.stringify(separate)))),geometry(separate));
  }
  assert.equal(clean({version:1}).leafArrangement,'single');
  assert.equal(clean({version:1}).crossTip,'none');
  // Crescent arcs share endpoints and a consistent circular inner boundary.
  for(const crescentHornAngle of [35,65,90,100]) for(const crescentThickness of [10,45,90]) {
    const model=clean({...defaults,shape:'crescent',moonBody:'classic',crescentHornAngle,crescentThickness});
    const a=crescentHornAngle*Math.PI/180,x=100*Math.cos(a),y=100*Math.sin(a),m=-100+(x+100)*crescentThickness/100,c=(10000-m*m)/(2*(x-m)),r=c-m;
    assert.ok(r>0); assert.ok(m>-100&&m<x);
    assert.ok(Math.abs(Math.hypot(x-c,y)-r)<1e-7);
    const out=geometry(model); assert.equal((out.match(/ A/g)||[]).length,2); assert.ok(!out.includes(' Q'));
  }
  const manyStar=clean({...defaults,shape:'star',arms:64});
  assert.equal(manyStar.arms,64); assert.equal(clean({...manyStar,arms:1000}).arms,64);
  assert.equal(clean({...manyStar,shape:'snow'}).arms,16);
  assert.equal((geometry(manyStar).match(/L/g)||[]).length,127);
  const multi={...defaults,shape:'cross',crossTip:'multi',crossSplitCount:5};
  for(const k of ['crossSplitCount','crossTipFlat','crossCenterLift','crossTipCurl']) {
    const v={crossSplitCount:7,crossTipFlat:50,crossCenterLift:35,crossTipCurl:45}[k];
    assert.notEqual(geometry(multi),geometry({...multi,[k]:v}));
  }
  assert.notEqual(geometry(multi),geometry({...multi,crossSplitStyle:'u'}));
  for(const crossSplitCount of [2,7]) for(const crossSplitDepth of [5,65]) for(const crossTipCurl of [-60,60]) for(const crossTipFlat of [0,70]) {
    const model=clean({...multi,crossSplitCount,crossSplitDepth,crossTipCurl,crossTipFlat,crossSplitStyle:'u',crossCenterLift:45});
    assert.ok(!/NaN|undefined|Infinity/.test(svg(model)));
    assert.equal(geometry(model),geometry(clean(JSON.parse(JSON.stringify(model)))));
  }
  // Deformation is shared by every shape, including nested leaf/branch transforms.
  for(const shape of Object.keys(shapeNames)) for(const swirlAngle of [-160,160]) {
    const model=clean({...defaults,shape,swirlAngle,fill:'gold',texture:'halftone'});
    const out=svg(model);assert.ok(!/NaN|undefined|Infinity/.test(out),shape+' swirl');
    assert.ok(!source(model).includes(' A'),shape+' deformed arcs should be sampled');
    assert.equal(source(model),source(clean(JSON.parse(JSON.stringify(model)))));
  }
  for(const p of [[0,0],[100,0],[20,-30],[-150,25]]) {
    const q=swirlPoint(p,{...defaults,swirlAngle:240});assert.ok(Math.abs(Math.hypot(...p)-Math.hypot(...q))<1e-8);
  }
  assert.deepEqual(swirlPoint([20,30],{...defaults,swirlAngle:0}),[20,30]);
  const nested={...defaults,shape:'leaf',leafArrangement:'alternate',swirlAngle:180};
  assert.ok(!/NaN|undefined/.test(svg(nested)));
  const ink={...defaults,shape:'s',pressureOn:true,swirlAngle:-160};
  assert.ok(!/NaN|undefined/.test(svg(ink)));
  assert.ok(samplePath('M6.1e-15,-100 L100,0Z').length>2);
  for(const crossArms of [3,4,5,8,16]) for(const [crossTip] of tipOptions) {
    const model=clean({...defaults,shape:'cross',crossArms,crossTip});
    const out=svg(model);assert.ok(!/NaN|undefined|Infinity/.test(out));assert.equal(crossCaps(model).length,crossArms);
    const sep={...model,crossTipSeparate:true,crossTipArm0:'drop',crossTipArm1:'fleur'};
    assert.equal(geometry(sep),geometry(clean(JSON.parse(JSON.stringify(sep)))));
  }
  for(const k of ['fleurCurve','fleurTurn','fleurNeck']) {
    assert.notEqual(geometry({...defaults,shape:'cross',crossTip:'fleur',[k]:0}),geometry({...defaults,shape:'cross',crossTip:'fleur',[k]:80}));
  }
  assert.equal(clean({version:1}).lineFeel,'vector');
  for(const shape of Object.keys(shapeNames)) for(const lineFeel of Object.keys(lineFeels)) {
    const model=clean({...defaults,shape,lineFeel,pressureOn:true,strokeWidth:12,brushStrength:75});
    const out=svg(model);assert.ok(!/NaN|undefined|Infinity/.test(out),shape+' '+lineFeel);
    const ids=[...out.matchAll(/\\bid="([^"]+)"/g)].map(m=>m[1]);
    assert.equal(new Set(ids).size,ids.length);
    for(const match of out.matchAll(/(?:url\\(#|href="#)([^)"]+)/g))assert.ok(ids.includes(match[1]),shape+' '+match[1]);
    assert.equal(source(model),source(clean(JSON.parse(JSON.stringify(model)))));
    if(lineFeel!=='vector')assert.ok(out.includes('brushPaint'));
  }
  const closedContours=pathContours(geometry({...defaults,shape:'circle',circleHole:45}));
  assert.equal(closedContours.length,2);assert.ok(closedContours.every(c=>c.closed));
  const circularStroke=contourRibbon({...defaults,pressureOn:true},closedContours[0].points,true);
  assert.ok((circularStroke.match(/Z/g)||[]).length>2);
  const originalRender=render,originalToast=toast;render=()=>{};toast=()=>{};
  state=clean({...defaults,shape:'cross',step:3,crossArms:8,lineFeel:'pastel'});commit();
  previousStep();assert.equal(state.step,2);assert.equal(state.crossArms,8);assert.equal(state.lineFeel,'pastel');
  resetProject();assert.equal(state.step,0);assert.equal(state.shape,defaults.shape);assert.equal(state.lineFeel,'vector');
  undo();assert.equal(state.crossArms,8);assert.equal(state.lineFeel,'pastel');assert.equal(state.step,2);
  render=originalRender;toast=originalToast;
  // Regression: additive rounded joins cannot cancel into twisted holes.
  const signedArea=poly=>poly.reduce((sum,p,i)=>{const q=poly[(i+1)%poly.length];return sum+p[0]*q[1]-p[1]*q[0]},0)/2;
  const winding=(poly,p)=>{let w=0;for(let i=0;i<poly.length;i++){const a=poly[i],b=poly[(i+1)%poly.length],cross=(b[0]-a[0])*(p[1]-a[1])-(p[0]-a[0])*(b[1]-a[1]);if(a[1]<=p[1]){if(b[1]>p[1]&&cross>0)w++}else if(b[1]<=p[1]&&cross<0)w--}return w};
  for(const lineFeel of Object.keys(lineFeels)) for(const closed of [false,true]) {
    const pts=[[0,0],[0,0],[20,0],[20,10],[0,1],[-10,-5]],model={...defaults,pressureOn:true,lineFeel,strokeWidth:24,pressureStart:0,pressureMiddle:300,pressureEnd:0,pressurePeak:15,brushStrength:100};
    const sections=pressureSections(model,pts,closed);
    assert.ok(sections.pieces.length>0);
    for(const poly of sections.pieces){assert.ok(signedArea(poly)>0);assert.ok(poly.flat().every(Number.isFinite))}
    if(!closed){assert.equal(sections.radii[0],0);assert.equal(sections.radii.at(-1),0)}
    for(let i=1;i<sections.points.length-1;i++)assert.ok(sections.pieces.reduce((w,poly)=>w+winding(poly,sections.points[i]),0)>0,'tight-turn centerline must stay filled');
    const out=contourInk(model,geometry({...model,shape:'s'}),'#000000');assert.ok(out.includes('fill-rule="nonzero"'));
  }
  for(const shape of ['leaf','crescent','star','cross','spiral','s'])for(const lineFeel of ['vector','charcoal']) {
    const model=clean({...defaults,shape,lineFeel,pressureOn:true,strokeWidth:24,pressureMiddle:300,pressureStart:0,pressureEnd:0});
    for(const c of pathContours(geometry(model)))assert.ok(!/NaN|Infinity/.test(contourRibbon(model,c.points,c.closed)));
  }
  // Every dedicated field affects its own shape and survives v1 project roundtrips.
  for(const [shape,fields] of Object.entries(morphSpecs)) {
    const neutral=clean({...defaults,shape});assert.equal(geometry(neutral),rawGeometry(neutral),shape+' neutral geometry');
    for(const f of fields){let model={...neutral};const primary=morphGroupDefs[f.group].primary;if(primary&&primary!==f.suffix)model[morphKey(shape,primary)]={bend:30,notchDepth:25,edgeDepth:10,waist:30}[primary];
      const lo=clean({...model,[f.key]:f.min}),hi=clean({...model,[f.key]:f.suffix==='edgePhase'?180:f.max}),a=geometry(lo),b=geometry(hi);
      assert.notEqual(a,b,shape+' '+f.suffix+' must affect geometry');
      assert.ok(!/NaN|undefined|Infinity/.test(a+b),shape+' '+f.suffix);
      assert.equal(geometry(clean(JSON.parse(JSON.stringify(hi)))),b);
      assert.equal(clean({...model,[f.key]:1e9})[f.key],f.max);
    }
    const combined={...neutral};for(const f of fields){if(['bend','asymmetry','shear','waist','notchDepth'].includes(f.suffix))combined[f.key]=20;if(f.suffix==='edgeDepth')combined[f.key]=8;if(f.suffix==='topWidth')combined[f.key]=75;if(f.suffix==='bottomWidth')combined[f.key]=120}
    const out=svg(clean({...combined,pressureOn:true,strokeWidth:8,swirlAngle:40}));assert.ok(!/NaN|undefined|Infinity/.test(out),shape+' combined morph/pressure/swirl');
  }
  assert.equal(hasShapeMorph(clean({version:1,shape:'petal'})),false);
  const leafMorph={...defaults,shape:'leaf',leafArrangement:'alternate',[morphKey('leaf','notchDepth')]:25,[morphKey('leaf','topWidth')]:70};
  assert.equal(geometry(leafMorph),rawGeometry(leafMorph),'paired leaves must be deformed exactly once per leaf');
  const one=geometry({...leafMorph,leafArrangement:'single'});assert.ok(geometry(leafMorph).includes(one));
  const unlinked={...defaults,shape:'heart',[morphKey('petal','bend')]:45};assert.equal(geometry(unlinked),geometry({...defaults,shape:'heart'}));
  for(const key of shapeKeys.petal)unlinked[key]=defaults[key];assert.equal(unlinked[morphKey('petal','bend')],0);
  assert.equal(Object.keys(shapeNames).length,32);
  for(const arrowHead of ['triangle','chevron','diamond','spear','round','heart','fleur'])for(const arrowTail of ['none','bar','circle','feather','fork'])for(const arrowDouble of [false,true]) {
    const model=clean({...defaults,shape:'arrow',arrowHead,arrowTail,arrowDouble,arrowBend:45,arrowHeadTilt:15});
    const out=svg(model);assert.ok(!/NaN|undefined|Infinity/.test(out));assert.equal(geometry(model),geometry(clean(JSON.parse(JSON.stringify(model)))));
  }
  for(const arrowBend of [-100,100])for(const arrowLength of [120,260]) {const model=clean({...defaults,shape:'arrow',arrowBend,arrowLength,arrowShaftWidth:50,arrowHeadLength:70});assert.ok(!/NaN|undefined|Infinity/.test(svg(model)))}
  const arrowBase={...defaults,shape:'arrow'};
  const arrowContour=pathContours(geometry(arrowBase))[0].points;
  assert.ok(Math.min(...arrowContour.map(p=>p[1]))<=-99.99,'arrowhead must face outward');
  const feather={...arrowBase,arrowTail:'feather'};
  for(const [key,val] of [['arrowTailWidth',90],['arrowTailLength',60],['arrowFeathers',5],['arrowFeatherAngle',75]])assert.notEqual(geometry(feather),geometry({...feather,[key]:val}),key);
  for(const shieldBottom of ['point','round','flat']) {
    const model=clean({...defaults,shape:'shield',shieldBottom});assert.ok(!/NaN|undefined|Infinity/.test(svg(model)));
    if(shieldBottom==='flat')assert.notEqual(geometry(model),geometry({...model,shieldBottomWidth:60}));
    if(shieldBottom==='round')assert.notEqual(geometry(model),geometry({...model,shieldRound:50}));
  }
  for(const ribbonEnd of ['flat','fork','point'])for(const ribbonLeftOn of [false,true])for(const ribbonRightOn of [false,true]) {
    const model=clean({...defaults,shape:'ribbon',ribbonEnd,ribbonLeftOn,ribbonRightOn});assert.ok(!/NaN|undefined|Infinity/.test(svg(model)));
    assert.equal(geometry(model),geometry(clean(JSON.parse(JSON.stringify(model)))));
  }
  for(const key of ['ribbonLeftLength','ribbonRightLength','ribbonCut'])assert.notEqual(geometry({...defaults,shape:'ribbon'}),geometry({...defaults,shape:'ribbon',[key]:60}));
  assert.notEqual(geometry({...defaults,shape:'ribbon'}),geometry({...defaults,shape:'ribbon',ribbonFoldLines:false}));
  for(const shape of ['arrow','shield','ribbon']) {const model=clean({...defaults,shape,pressureOn:true,lineFeel:'charcoal',swirlAngle:70,texture:'halftone',mode:'radial'});assert.ok(!/NaN|undefined|Infinity/.test(svg(model)))}
  // Curved arrow wings keep their attachment and tip anchored for every head style.
  for(const arrowHead of ['triangle','chevron','diamond','spear','round','heart','fleur']) {
    const base={...defaults,shape:'arrow',arrowHead},original=arrowHeadCap(base,9);
    for(const arrowHeadCurve of [-70,70]) {
      const curved=arrowHeadCap({...base,arrowHeadCurve},9);
      assert.deepEqual(curved[0],original[0]);assert.deepEqual(curved.at(-1),original.at(-1));
      assert.ok(curved.some(p=>Math.abs(p[0])<1e-8&&Math.abs(p[1]+base.arrowHeadLength)<1e-8));
      assert.notEqual(JSON.stringify(curved),JSON.stringify(original));
      assert.notEqual(geometry({...base,arrowHeadCurve,arrowHeadCurveBias:-60}),geometry({...base,arrowHeadCurve,arrowHeadCurveBias:60}));
      assert.ok(!/NaN|Infinity|undefined/.test(svg({...base,arrowHeadCurve,arrowHeadCurveBias:60,arrowDouble:true,arrowBend:100,pressureOn:true,swirlAngle:70})));
    }
  }
  const movingRibbon={...defaults,shape:'ribbon',ribbonTailWave:24,ribbonWindStrength:40,ribbonTiers:3};
  for(const [key,value] of [['ribbonTailWave',0],['ribbonTailCycles',2.5],['ribbonTailPhase',90],['ribbonWindStrength',0],['ribbonWindAngle',90],['ribbonTension',100],['ribbonStepHeight',35],['ribbonTiers',5],['ribbonTierGap',90],['ribbonStepX',50],['ribbonTierScale',75]]) {
    const model={...movingRibbon,[key]:value};assert.notEqual(geometry(model),geometry(movingRibbon),key+' should alter ribbon');
    assert.equal(geometry(clean(JSON.parse(JSON.stringify(model)))),geometry(model),key+' roundtrip');assert.ok(shapeKeys.ribbon.includes(key),key+' reset');
  }
  for(const ribbonTiers of [1,2,3,4,5])for(const ribbonEnd of ['flat','fork','point'])for(const ribbonWindAngle of [-180,-90,0,90,180]) {
    const model=clean({...movingRibbon,ribbonTiers,ribbonEnd,ribbonWindAngle,ribbonHeight:20,ribbonLeftLength:15,ribbonRightLength:15,ribbonTailWave:30,ribbonWindStrength:60,ribbonTension:0,ribbonStepHeight:45,ribbonStepX:60,ribbonTierScale:110});
    const geo=geometry(model);assert.ok(!/NaN|Infinity|undefined/.test(geo));
    if(ribbonTiers>1)for(const contour of pathContours(geo))for(const p of contour.points)assert.ok(Math.max(Math.abs(p[0]),Math.abs(p[1]))<=150.01,'multiple tiers fit');
  }
  const still={...defaults,shape:'ribbon',ribbonLeftOn:false,ribbonRightOn:false};
  assert.equal(geometry({...still,ribbonTailWave:30,ribbonWindStrength:60,ribbonStepHeight:45}),geometry(still),'hidden tails must not deform center');
  assert.equal(clean({...defaults,ribbonTiers:3.7}).ribbonTiers,4);
  assert.equal(clean({...defaults,ribbonTiers:99}).ribbonTiers,5);
  assert.equal(clean({...defaults,arrowHeadCurve:-999}).arrowHeadCurve,-70);
  for(const key of ['arrowHeadCurve','arrowHeadCurveBias'])assert.ok(shapeKeys.arrow.includes(key));
  assert.ok(!/NaN|Infinity|undefined/.test(svg({...movingRibbon,pressureOn:true,lineFeel:'charcoal',swirlAngle:75})));
  // Folded banner: back tails and diagonal return faces paint before the central face.
  const folded={...defaults,shape:'ribbon',ribbonConstruction:'folded',ribbonSag:0,ribbonFold:24};
  const foldGeo=geometry(folded),frontTag=foldGeo.match(/<path data-ribbon-part="front"[^>]*\\/>/)[0];
  assert.equal((foldGeo.match(/data-ribbon-part="tail"/g)||[]).length,2);
  assert.equal((foldGeo.match(/data-ribbon-shade/g)||[]).length,2);
  assert.ok(foldGeo.indexOf('data-ribbon-shade')<foldGeo.indexOf('data-ribbon-part="front"'));
  assert.equal(geometry({...folded,ribbonFold:0}).includes('data-ribbon-shade'),false);
  assert.equal(geometry({...folded,ribbonLeftOn:false,ribbonRightOn:false}).includes('data-ribbon-part="tail"'),false);
  for(const [key,value] of [['ribbonFold',40],['ribbonOverlap',50],['ribbonFrontWidth',300]])assert.notEqual(geometry({...folded,[key]:value}),foldGeo,key);
  const painted=source(folded,true);assert.ok(painted.lastIndexOf('data-ribbon-part="front"')>painted.lastIndexOf('data-ribbon-shade'));
  assert.notEqual(source({...folded,ribbonFoldShade:0}),source({...folded,ribbonFoldShade:40}));
  assert.equal(source({...folded,fill:'none',ribbonFoldShade:40}).includes('fill="#000000"'),false,'no solid fold shadows in outline-only export');
  for(const ribbonConstruction of ['folded','continuous'])for(const ribbonWearStyle of ['chips','tears','ragged'])for(const ribbonWearTarget of ['all','front','tails']) {
    const worn={...folded,ribbonConstruction,ribbonWearStyle,ribbonWearTarget,ribbonWear:80,ribbonWearDepth:10,ribbonWearCount:12};
    const damaged=geometry(worn);assert.notEqual(damaged,geometry({...worn,ribbonWear:0}));
    assert.equal(damaged,geometry(worn),'seeded wear must be repeatable');
    assert.equal(damaged,geometry(clean(JSON.parse(JSON.stringify(worn)))),'wear roundtrip');
    for(const [key,value] of [['ribbonWearDepth',2],['ribbonWearCount',4],['ribbonWearRough',90],['ribbonWearSeed',37]])assert.notEqual(damaged,geometry({...worn,[key]:value}),key);
    assert.ok(!/NaN|Infinity|undefined/.test(svg({...worn,pressureOn:true,lineFeel:'pencil',swirlAngle:50})));
    if(ribbonConstruction==='folded'&&ribbonWearTarget==='tails')assert.equal(damaged.match(/<path data-ribbon-part="front"[^>]*\\/>/)[0],frontTag,'tail wear must preserve front');
  }
  for(const ribbonWearStyle of ['chips','tears','ragged']) {
    const out=geometry({...folded,ribbonHeight:20,ribbonWear:100,ribbonWearDepth:14,ribbonWearCount:24,ribbonWearRough:100,ribbonWearStyle,ribbonTiers:5,ribbonTailWave:30,ribbonWindStrength:60,ribbonTension:0});
    assert.ok(!/NaN|Infinity|undefined/.test(out));for(const c of pathContours(out))for(const p of c.points)assert.ok(Math.max(Math.abs(p[0]),Math.abs(p[1]))<=150.01);
  }
  const rectangle=[[-120,-20],[120,-20],[120,20],[-120,20]];
  for(const ribbonWearStyle of ['chips','tears','ragged'])for(const p of wearRibbonOutline(rectangle,{...folded,ribbonHeight:40,ribbonWear:100,ribbonWearDepth:14,ribbonWearStyle},3,'front'))assert.ok(p[0]>=-120&&p[0]<=120&&p[1]>=-20&&p[1]<=20,'weathering must cut inward');
  for(const key of ['ribbonFrontWidth','ribbonConstruction','ribbonOverlap','ribbonFoldShade','ribbonWear','ribbonWearDepth','ribbonWearCount','ribbonWearRough','ribbonWearSeed','ribbonWearTarget','ribbonWearStyle'])assert.ok(shapeKeys.ribbon.includes(key),key+' reset');
  assert.equal(clean({...folded,ribbonWear:999,ribbonOverlap:999,ribbonWearSeed:3.7}).ribbonWear,100);
  assert.equal(clean({...folded,ribbonWearSeed:3.7}).ribbonWearSeed,4);
  // Fold count adds connected return faces within one banner, independently of tier stacking.
  for(let ribbonFoldCount=1;ribbonFoldCount<=6;ribbonFoldCount++) {
    const model=clean({...defaults,shape:'ribbon',ribbonFoldCount,ribbonSag:0,ribbonFold:24,ribbonWear:35}),geo=geometry(model);
    assert.equal((geo.match(/data-ribbon-part="step"/g)||[]).length,2*(ribbonFoldCount-1));
    assert.equal((geo.match(/data-ribbon-part="tail"/g)||[]).length,2);
    assert.equal((geo.match(/data-ribbon-shade/g)||[]).length,2*ribbonFoldCount);
    assert.equal(geo,geometry(clean(JSON.parse(JSON.stringify(model)))));
    const leftOnly=geometry({...model,ribbonRightOn:false});assert.equal((leftOnly.match(/data-ribbon-shade/g)||[]).length,ribbonFoldCount);
    assert.ok(!/NaN|Infinity|undefined/.test(geo));
    if(ribbonFoldCount>1)for(const c of pathContours(geo))for(const p of c.points)assert.ok(Math.max(Math.abs(p[0]),Math.abs(p[1]))<=150.01);
  }
  assert.equal(clean({...defaults,ribbonFoldCount:3.7}).ribbonFoldCount,4);
  assert.equal(clean({...defaults,ribbonFoldCount:999}).ribbonFoldCount,6);
  assert.ok(shapeKeys.ribbon.includes('ribbonFoldCount'));
  assert.equal(geometry({...defaults,shape:'ribbon',ribbonConstruction:'continuous',ribbonFoldCount:6}),geometry({...defaults,shape:'ribbon',ribbonConstruction:'continuous',ribbonFoldCount:1}));
  // Projection uses real XYZ rotations and a bounded perspective divide.
  assert.equal(viewMarkup('<path d="M0,0L10,10"/>',defaults),'<path d="M0,0L10,10"/>');
  const xTilt=viewPoint([0,100],{...defaults,viewX:60,viewPerspective:0});assert.ok(Math.abs(xTilt[1]-50)<1e-8);
  const yTilt=viewPoint([100,0],{...defaults,viewY:60,viewPerspective:0});assert.ok(Math.abs(yTilt[0]-50)<1e-8);
  const zTurn=viewPoint([100,0],{...defaults,viewZ:90});assert.ok(Math.abs(zTurn[0])<1e-8&&Math.abs(zTurn[1]-100)<1e-8);
  const perspective=viewPoint([100,40],{...defaults,viewY:50,viewPerspective:100}),parallel=viewPoint([100,40],{...defaults,viewY:50,viewPerspective:0});assert.notEqual(perspective[0],parallel[0]);
  const nestedViewProjection=viewMarkup('<g transform="translate(10 20)"><g transform="scale(2)"><path d="M1,2L3,4"/></g></g>',{...defaults,viewZ:90,viewPerspective:0});
  const projectedPoints=pathContours(nestedViewProjection)[0].points;assert.ok(Math.abs(projectedPoints[0][0]+24)<1e-8&&Math.abs(projectedPoints[0][1]-12)<1e-8,'nested transforms must apply once');
  for(const shape of Object.keys(shapeNames)) {
    const flat={...defaults,shape};const neutral=source(flat);
    for(const [key,value] of [['viewX',45],['viewY',-45],['viewZ',35]]) {
      const model=clean({...flat,[key]:value}),out=source(model);assert.notEqual(out,neutral,shape+' '+key);assert.ok(!/NaN|Infinity|undefined/.test(out));
      assert.equal(out,source(clean(JSON.parse(JSON.stringify(model)))));assert.ok(shapeKeys[shape].includes(key));
    }
    const out=svg(clean({...flat,viewX:80,viewY:-80,viewZ:180,viewPerspective:100,mode:'radial',texture:'halftone',fill:'gold'}));assert.ok(!/NaN|Infinity|undefined/.test(out));
    const ids=[...out.matchAll(/\\bid="([^"]+)"/g)].map(m=>m[1]);for(const m of out.matchAll(/(?:url\\(#|href="#)([^)"]+)/g))assert.ok(ids.includes(m[1]));
  }
  for(const shape of ['ribbon','leaf','spiral'])assert.ok(!/NaN|Infinity|undefined/.test(svg({...defaults,shape,ribbonFoldCount:6,ribbonWear:40,viewX:45,viewY:-30,viewZ:20,viewPerspective:90,pressureOn:true,lineFeel:'pencil',swirlAngle:35})));
  const huge=viewMarkup('<g transform="scale(10000)"><path d="M-100,-100L100,100L100,-100Z"/></g>',{...defaults,viewX:80,viewY:80,viewPerspective:100});assert.ok(!/NaN|Infinity|undefined/.test(huge));
  const viewClean=clean({...defaults,viewX:999,viewY:-999,viewZ:999,viewPerspective:999});assert.equal(viewClean.viewX,80);assert.equal(viewClean.viewY,-80);assert.equal(viewClean.viewZ,180);assert.equal(viewClean.viewPerspective,100);
  // Moon silhouettes grow continuously to a complete disc; classic circular crescents remain available.
  let previousMoonArea=0;for(const moonFullness of [1,10,25,49,50,51,75,90,99,100]) {
    const model={...defaults,shape:'crescent',moonBody:'phase',moonFullness},pts=pathContours(geometry(model))[0].points;
    const area=Math.abs(pts.reduce((sum,p,i)=>{const q=pts[(i+1)%pts.length];return sum+p[0]*q[1]-q[0]*p[1]},0))/2;
    assert.ok(area>previousMoonArea,'phase must grow monotonically');assert.ok(Math.abs(area/(Math.PI*10000)-moonFullness/100)<.015);previousMoonArea=area;
  }
  assert.equal(geometry({...defaults,shape:'crescent',moonBody:'phase',moonFullness:100}),geometry({...defaults,shape:'crescent',moonBody:'full'}));
  assert.equal(moonPhasePath(0),'');
  assert.equal(clean({version:1,shape:'crescent'}).moonBody,'classic','old moon projects keep their silhouette');
  assert.equal(clean({version:1,shape:'crescent'}).moonCratersOn,false);
  const moonBase={...defaults,shape:'crescent',moonShadowOn:true,moonShadowCoverage:45};
  for(let mask=1;mask<32;mask++) {
    const model={...moonBase};moonStyles.forEach(([key],i)=>model[key]=!!(mask&(1<<i)));
    const placements=moonCraterPlacements(model),out=source(model);assert.ok(placements.length>0);
    for(const [key] of moonStyles)assert.equal(out.includes('data-moon-style="'+key+'"'),model[key],key+' selected style');
    assert.deepEqual(placements,moonCraterPlacements(model),'seeded positions repeat');
    assert.equal(source(clean(JSON.parse(JSON.stringify(model)))),out,'moon JSON roundtrip');
    for(const p of placements)assert.ok(Math.hypot(p.x,p.y)+p.r<=94.00001,'craters stay inside disc');
  }
  const none={...moonBase};moonStyles.forEach(([key])=>none[key]=false);assert.equal(moonCraterPlacements(none).length,0);
  assert.equal(moonCraterPlacements({...moonBase,moonCratersOn:false}).length,0);
  assert.equal(moonCraterPlacements({...moonBase,moonCraterDensity:0}).length,0);
  const sparse=moonCraterPlacements({...moonBase,moonCraterDensity:10}),dense=moonCraterPlacements({...moonBase,moonCraterDensity:100});assert.ok(dense.length>sparse.length);assert.deepEqual(dense.slice(0,sparse.length),sparse,'density extends the same placement sequence');
  for(const [key,value] of [['moonCraterSize',17],['moonCraterDensity',80],['moonCraterOpacity',20],['moonCraterColor','#123456'],['moonCraterSeed',9],['moonShadowCoverage',80],['moonShadowAngle',70],['moonShadowOpacity',80],['moonShadowColor','#112233']])assert.notEqual(source({...moonBase,[key]:value}),source(moonBase),key);
  for(const moonBody of ['full','phase','classic'])for(const moonShadowCoverage of [0,1,50,99,100]) {
    const model={...moonBase,moonBody,moonFullness:20,moonShadowCoverage,moonCasual:true,moonReal:true,moonHalftone:true,moonDiamond:true,moonChecker:true,viewX:45,viewY:-35,swirlAngle:45,[morphKey('crescent','bend')]:25};
    const out=svg(model);assert.ok(!/NaN|Infinity|undefined/.test(out));
    const ids=[...out.matchAll(/\\bid="([^"]+)"/g)].map(m=>m[1]);assert.equal(new Set(ids).size,ids.length);for(const m of out.matchAll(/(?:url\\(#|href="#)([^)"]+)/g))assert.ok(ids.includes(m[1]),'moon clip reference '+m[1]);
    assert.equal(source({...model,moonShadowOn:false}).includes('data-moon-shadow'),false);
    assert.equal(source(model).includes('data-moon-shadow'),moonShadowCoverage>0);
  }
  const moonA=svg(moonBase),moonB=svg(moonBase);const clipA=moonA.match(/id="(moonClip[0-9]+)"/)[1],clipB=moonB.match(/id="(moonClip[0-9]+)"/)[1];assert.notEqual(clipA,clipB,'separate SVGs must not share clip IDs');
  assert.ok(!source({...moonBase,moonCratersOn:false,moonImpactOn:false,moonShadowOn:false}).includes('clipPath'));
  for(const [key] of moonStyles)assert.ok(shapeKeys.crescent.includes(key));
  for(const key of ['moonBody','moonFullness','moonCratersOn','moonCraterDensity','moonCraterSize','moonCraterOpacity','moonCraterSeed','moonCraterColor','moonShadowOn','moonShadowCoverage','moonShadowOpacity','moonShadowAngle','moonShadowColor','crescentThickness','crescentHornAngle'])assert.ok(shapeKeys.crescent.includes(key),key+' reset');
  const moonBounded=clean({...moonBase,moonCraterDensity:999,moonCraterSize:-999,moonCraterSeed:3.8,moonFullness:999,moonCraterColor:'bad',moonBody:'bad'});assert.equal(moonBounded.moonCraterDensity,100);assert.equal(moonBounded.moonCraterSize,2);assert.equal(moonBounded.moonCraterSeed,4);assert.equal(moonBounded.moonFullness,100);assert.equal(moonBounded.moonCraterColor,defaults.moonCraterColor);assert.equal(moonBounded.moonBody,'full');
  // Lunar surface uses large connected maria, plus sparse impact details and optional rays.
  const terrainMoon={...defaults,shape:'crescent',moonCasual:true,moonReal:true,moonHalftone:true,moonDiamond:true,moonChecker:true};
  assert.ok(source(terrainMoon).includes('data-moon-terrain="graphic"'));assert.ok(source(terrainMoon).includes('data-moon-terrain="layered"'));
  assert.ok(source(terrainMoon).includes('data-moon-rays'));
  assert.equal(source({...terrainMoon,moonRayStrength:0}).includes('data-moon-rays'),false);
  for(const [key,value] of [['moonMareCoverage',15],['moonMareRoughness',0],['moonRayStrength',20]])assert.notEqual(source({...terrainMoon,[key]:value}),source(terrainMoon),key);
  assert.deepEqual(moonMarePaths(terrainMoon),moonMarePaths(terrainMoon));assert.equal(moonMarePaths({...terrainMoon,moonCraterDensity:0}).length,0);
  const mareBox=pathContours('<path d="'+moonMarePaths(terrainMoon)[0]+'"/>')[0].points;assert.ok(Math.max(...mareBox.map(p=>p[0]))-Math.min(...mareBox.map(p=>p[0]))>40,'maria are large surface regions');
  // Camera distance genuinely increases foreshortening; world Z raises the motif above a fixed floor.
  const camera={...defaults,viewX:65,viewY:-15,viewPerspective:100,viewDistance:380};
  const ratio=s=>Math.hypot(...viewPoint([100,120],s))/Math.hypot(...viewPoint([100,-120],s));
  assert.ok(ratio(camera)>ratio({...camera,viewDistance:1400})*1.5,'near camera must create a much larger near/far ratio');
  for(const [key,value] of [['viewDistance',900],['viewPosX',90],['viewPosY',90],['viewDepth',90]])assert.notEqual(source({...camera,[key]:value}),source(camera),key);
  const zeroOrtho={...camera,viewPerspective:0};assert.equal(source({...zeroOrtho,viewDistance:180}),source({...zeroOrtho,viewDistance:1400}),'parallel projection ignores camera distance');
  assert.notEqual(viewPoint([0,0],{...camera,viewDepth:90})[1],viewPoint([0,0],camera)[1],'world Z must lift the motif on screen');
  const crossed=viewMarkup('<path d="M-300,-300L300,-300L300,300L-300,300Z"/>',{...camera,viewDistance:180,viewDepth:180});assert.ok(!/NaN|Infinity|undefined/.test(crossed));
  assert.equal(projectCameraPath('M0,0L10,0L0,10Z',[1,0,0,1,0,0],{...defaults,viewDepth:180,viewDistance:180,viewPerspective:100}),'','geometry behind the near plane must be clipped');
  const plane={...terrainMoon,mode:'radial',count:5,itemScale:32,viewScope:'scene',viewX:60,viewY:-20,viewPerspective:90,viewDistance:380,frame:'square',decor:true};
  const projectedScene=svg(plane,{guides:true});assert.ok(projectedScene.includes('data-view-grid'));assert.ok(projectedScene.includes('data-view-labels'));assert.ok(!projectedScene.includes('<use '));
  const ids=[...projectedScene.matchAll(/\\bid="([^"]+)"/g)].map(m=>m[1]);assert.equal(new Set(ids).size,ids.length);for(const m of projectedScene.matchAll(/(?:url\\(#|href="#)([^)"]+)/g))assert.ok(ids.includes(m[1]),'whole-scene clip reference '+m[1]);
  assert.ok(!svg(plane,{guides:false}).includes('data-view-grid'),'floor must not enter exports');
  assert.ok(!svg({...plane,viewGrid:false},{guides:true}).includes('data-view-grid'));
  assert.notEqual(scene(plane),scene({...plane,viewScope:'motif'}));assert.equal((scene({...plane,viewScope:'motif'}).match(/<use /g)||[]).length,5);
  const fixedGrid=viewFloorGrid(camera);assert.equal(fixedGrid,viewFloorGrid({...camera,viewDepth:100,viewPosX:100,viewPosY:100}),'floor coordinates remain fixed while the motif moves');
  for(const shape of Object.keys(shapeNames))for(const viewScope of ['motif','scene']) {
    const model=clean({...defaults,shape,mode:'linear',count:3,viewScope,viewX:80,viewY:-80,viewZ:35,viewDistance:180,viewPerspective:100,viewDepth:180});const out=svg(model);assert.ok(!/NaN|Infinity|undefined/.test(out),shape+' extreme camera');
  }
  assert.ok(!/NaN|Infinity|undefined/.test(svg({...camera,shape:'polygon',mode:'fractal',fractalBranches:4,fractalDepth:4,viewScope:'scene'})));
  for(const key of ['moonMareCoverage','moonMareRoughness','moonRayStrength'])assert.ok(shapeKeys.crescent.includes(key));
  for(const shape of Object.keys(shapeNames))for(const key of ['viewDistance','viewPosX','viewPosY','viewDepth','viewGrid','viewScope'])assert.ok(shapeKeys[shape].includes(key));
  const restoredCamera=clean(JSON.parse(JSON.stringify(plane)));assert.equal(scene(restoredCamera),scene(plane));
  {
  // Ornamental heads preserve their attachment and tip while their own controls affect the silhouette.
  for(const arrowHead of ['heart','fleur'])for(const arrowDouble of [false,true])for(const arrowHeadCurve of [-70,0,70]) {
    const model=clean({...defaults,shape:'arrow',arrowHead,arrowDouble,arrowHeadCurve,arrowTail:'feather',arrowBend:60});
    const cap=arrowHeadCap(model,5);assert.deepEqual(cap[0],[-5,0]);assert.deepEqual(cap.at(-1),[5,0]);assert.ok(cap.some(p=>Math.abs(p[0])<1e-8&&Math.abs(p[1]+model.arrowHeadLength)<1e-8));
    assert.ok(!/NaN|Infinity|undefined/.test(geometry(model)));assert.equal(geometry(model),geometry(clean(JSON.parse(JSON.stringify(model)))));
  }
  for(const [arrowHead,key,value] of [['heart','arrowHeartCleft',65],['fleur','arrowLilySpread',135],['fleur','arrowLilyCurl',75],['fleur','arrowLilyBand',85]])assert.notEqual(geometry({...defaults,shape:'arrow',arrowHead}),geometry({...defaults,shape:'arrow',arrowHead,[key]:value}),key);
  const refinedFeather={...defaults,shape:'arrow',arrowTail:'feather',arrowFeathers:5};
  for(const [key,value] of [['arrowFeatherSpacing',150],['arrowFeatherSweep',-50],['arrowFeatherTaper',75],['arrowFeatherNotch',15],['arrowFeatherStagger',75],['arrowFeatherTip','round']])assert.notEqual(geometry(refinedFeather),geometry({...refinedFeather,[key]:value}),key);
  // Every vane follows a monotone length axis, so steep sweep/stagger cannot cross adjacent vanes.
  const properCross=(a,b,c,d)=>{const turn=(p,q,r)=>(q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0]);return turn(a,b,c)*turn(a,b,d)<-1e-8&&turn(c,d,a)*turn(c,d,b)<-1e-8};
  for(const arrowFeathers of [1,3,9])for(const arrowFeatherSweep of [-60,60])for(const arrowFeatherTip of ['point','round','flat'])for(const arrowFeatherSpacing of [55,160]) {
    const model={...refinedFeather,arrowFeathers,arrowFeatherSweep,arrowFeatherTip,arrowFeatherSpacing,arrowFeatherStagger:80,arrowFeatherTaper:80,arrowFeatherNotch:10},cap=arrowTailCap(model,5);assert.ok(cap.every(p=>p.every(Number.isFinite)));
    for(let i=0;i<cap.length;i++)for(let j=i+2;j<cap.length;j++)assert.ok(!properCross(cap[i],cap[(i+1)%cap.length],cap[j],cap[(j+1)%cap.length]),'feather outline must not cross itself');
  }
  assert.equal(clean({...defaults,arrowFeathers:100}).arrowFeathers,9);assert.equal(clean({...defaults,arrowTailLength:100}).arrowTailLength,90);
  for(const flowerPetalTip of ['round','point','notched'])for(const flowerLayers of [1,2,4])for(const flowerPetals of [3,8,24]) {
    const model=clean({...defaults,shape:'flower',flowerPetalTip,flowerLayers,flowerPetals}),out=geometry(model);assert.equal((out.match(/data-flower-petal/g)||[]).length,flowerLayers*flowerPetals);assert.equal((out.match(/data-flower-center/g)||[]).length,1);assert.ok(!/NaN|Infinity|undefined/.test(out));assert.equal(out,geometry(clean(JSON.parse(JSON.stringify(model)))));
  }
  const layeredFlower={...defaults,shape:'flower',flowerLayers:3,flowerPetalTip:'notched'};
  for(const [key,value] of [['flowerLayerScale',60],['flowerLayerTwist',50],['flowerNotch',45],['flowerCenterOn',false]])assert.notEqual(geometry(layeredFlower),geometry({...layeredFlower,[key]:value}),key);
  for(const sunRayStyle of ['triangle','flame','round','line'])for(const sunRays of [4,16,64]) {
    const model=clean({...defaults,shape:'sun',sunRayStyle,sunRays}),out=geometry(model);assert.equal((out.match(/data-sun-ray/g)||[]).length,sunRays);assert.equal((out.match(/data-sun-core/g)||[]).length,1);assert.ok(!/NaN|Infinity|undefined/.test(out));assert.equal(out,geometry(clean(JSON.parse(JSON.stringify(model)))));
  }
  const sunBase={...defaults,shape:'sun'};for(const [key,value] of [['sunAlternate',false],['sunAlternateLength',90],['sunCoreOn',false],['sunCoreHole',65]])assert.notEqual(geometry(sunBase),geometry({...sunBase,[key]:value}),key);
  const sunCore=geometry({...sunBase,sunCoreHole:60}).match(/<path data-sun-core="true"[^>]*\\/>/)[0],holeContours=pathContours(sunCore);assert.equal(holeContours.length,2);const signedArea=pts=>pts.reduce((sum,p,i)=>{const q=pts[(i+1)%pts.length];return sum+p[0]*q[1]-q[0]*p[1]},0);assert.ok(signedArea(holeContours[0].points)*signedArea(holeContours[1].points)<0,'sun core hole winding');
  for(const shape of ['flower','sun'])for(const lineFeel of ['vector','pencil']) {
    const model={...defaults,shape,flowerLayers:3,flowerPetalTip:'notched',sunRayStyle:'flame',pressureOn:true,lineFeel,viewX:55,viewY:-25,viewPerspective:90,swirlAngle:25,mode:'radial',count:3,itemScale:25};const out=svg(model);assert.ok(!/NaN|Infinity|undefined/.test(out));
    assert.ok(source(model).lastIndexOf(shape==='flower'?'data-flower-center':'data-sun-core')>source(model).lastIndexOf(shape==='flower'?'data-flower-petal':'data-sun-ray'),'center paints over petal/ray bases');
  }
  for(const key of ['arrowHeartCleft','arrowLilySpread','arrowLilyCurl','arrowLilyBand','arrowFeatherSpacing','arrowFeatherSweep','arrowFeatherTaper','arrowFeatherNotch','arrowFeatherStagger','arrowFeatherTip'])assert.ok(shapeKeys.arrow.includes(key),key+' reset');
  for(const shape of ['flower','sun'])for(const key of newShapeKeys[shape])assert.ok(shapeKeys[shape].includes(key));
  const newBounded=clean({...defaults,flowerPetals:999,flowerLayers:2.8,sunRays:999,flowerPetalTip:'bad',sunRayStyle:'bad',arrowHead:'heart',arrowFeatherTip:'bad'});assert.equal(newBounded.flowerPetals,48);assert.equal(newBounded.flowerLayers,3);assert.equal(newBounded.sunRays,64);assert.equal(newBounded.arrowHead,'heart');assert.equal(newBounded.flowerPetalTip,'round');assert.equal(newBounded.sunRayStyle,'triangle');assert.equal(newBounded.arrowFeatherTip,'point');
  }
  { // Independent crater controls, fixed counts, and retained decorative pattern geometry.
  const impacts={...defaults,shape:'crescent',moonCratersOn:false,moonShadowOn:false};
  for(const moonImpactCount of [0,1,14,60])for(const moonImpactDensity of [0,50,100]) {
    const model=clean({...impacts,moonImpactCount,moonImpactDensity}),p=moonImpactPlacements(model);assert.equal(p.length,moonImpactCount);assert.equal((moonImpactMarkup(model).match(/data-moon-impact=/g)||[]).length,moonImpactCount);assert.ok(p.every(q=>Math.hypot(q.x,q.y)+q.r*1.18<=97.00001));
    assert.deepEqual(p,moonImpactPlacements(clean(JSON.parse(JSON.stringify(model)))));
  }
  const spread=moonImpactPlacements({...impacts,moonImpactDensity:0}),cluster=moonImpactPlacements({...impacts,moonImpactDensity:100});const meanRadius=p=>p.reduce((sum,q)=>sum+Math.hypot(q.x,q.y),0)/p.length;assert.ok(meanRadius(cluster)<meanRadius(spread)*.6,'density concentrates the same count');
  assert.deepEqual(moonImpactPlacements({...impacts,moonImpactSize:4}).map(p=>[p.x,p.y]),moonImpactPlacements({...impacts,moonImpactSize:8}).map(p=>[p.x,p.y]),'size preserves centers away from the moon edge');
  for(const [key,value] of [['moonImpactSize',18],['moonImpactCount',5],['moonImpactDensity',85],['moonImpactX',30],['moonImpactY',-30],['moonImpactRotation',70],['moonImpactRoughness',90],['moonImpactShade',20],['moonImpactRim',10],['moonImpactLight',60],['moonImpactOpacity',30],['moonImpactColor','#112233'],['moonImpactSeed',7]])assert.notEqual(moonImpactMarkup({...impacts,[key]:value}),moonImpactMarkup(impacts),key+' independent control');
  assert.ok(!moonImpactMarkup({...impacts,moonImpactShade:0}).includes('data-impact-wall'));
  assert.equal(moonImpactMarkup({...impacts,moonImpactOn:false}),'');assert.ok(source(impacts).includes('data-moon-impact'),'craters work with patterns off');
  const edits=Object.fromEntries(Array.from({length:60},(_,i)=>[i,[i%20,i%20?-(i%20):0]])),edited=clean({...impacts,moonImpactCount:60,moonImpactSelected:31,moonImpactOffsets:JSON.stringify(edits)});assert.ok(edited.moonImpactOffsets.length>100);assert.deepEqual(JSON.parse(edited.moonImpactOffsets),edits);assert.equal(edited.moonImpactOffsetX,10);assert.equal(edited.moonImpactOffsetY,-10);assert.deepEqual(clean(JSON.parse(JSON.stringify(edited))),edited);
  const oneEdit={...impacts,moonImpactOffsets:'{"2":[12,-10]}'},before=moonImpactPlacements(impacts),after=moonImpactPlacements(oneEdit);for(let i=0;i<before.length;i++){if(i===2)assert.notDeepEqual(before[i],after[i]);else assert.deepEqual(before[i],after[i],'individual edits preserve other positions')}
  assert.equal(normalizeImpactOffsets('{"0":[200,-200],"1":["1",2],"99":[1,2],"__proto__":[1,2]}'),'{"0":[90,-90]}');assert.equal(normalizeImpactOffsets('bad'),'{}');assert.equal(normalizeImpactOffsets('[]'),'{}');
  const mixed={...impacts,moonCratersOn:true,moonCasual:false,moonReal:false,moonHalftone:true,moonDiamond:true,moonChecker:true};assert.equal(moonCraterMarkup({...mixed,moonImpactCount:2,moonImpactShade:10,moonImpactX:60}),moonCraterMarkup(mixed),'crater controls do not alter patterns');
  assert.equal(moonImpactMarkup({...mixed,moonHalftone:false,moonDiamond:false,moonChecker:false}),moonImpactMarkup(mixed),'pattern toggles do not alter craters');
  assert.notEqual(moonOverlay(geometry(mixed),mixed),moonOverlay(geometry(mixed),{...mixed,moonPatternsOverCraters:true}));
  const preview=svg({...mixed,moonImpactEditOn:true,step:0},{guides:true});assert.ok(preview.includes('data-impact-guide'));assert.ok(!svg({...mixed,moonImpactEditOn:true,step:0},{guides:false}).includes('data-impact-guide'),'selection guide excluded from output');
  for(const moonBody of ['full','phase','classic']) {
    const model={...mixed,moonBody,moonFullness:20,moonImpactRoughness:100,moonImpactSize:24,viewX:60,viewY:-25,swirlAngle:30,mode:'radial',count:3,itemScale:25};const out=svg(model);assert.ok(!/NaN|Infinity|undefined/.test(out));const ids=[...out.matchAll(/\\bid="([^"]+)"/g)].map(m=>m[1]);assert.equal(new Set(ids).size,ids.length);for(const m of out.matchAll(/(?:url\\(#|href="#)([^)"]+)/g))assert.ok(ids.includes(m[1]));
  }
  for(const key of Object.keys(defaults).filter(k=>k.startsWith('moonImpact')||k==='moonPatternsOverCraters'))assert.ok(shapeKeys.crescent.includes(key),key+' reset');
  const bounded=clean({...impacts,moonImpactCount:99,moonImpactSelected:99,moonImpactSize:-99,moonImpactRoughness:999,moonImpactColor:'bad'});assert.equal(bounded.moonImpactCount,60);assert.equal(bounded.moonImpactSelected,60);assert.equal(bounded.moonImpactSize,2);assert.equal(bounded.moonImpactRoughness,100);assert.equal(bounded.moonImpactColor,defaults.moonImpactColor);
  }
  const patternBaselines=["dd53d218ca5c49f71ab15a04dd2c7e8b93872dce5e12a968a900bb6450cbd9c0","8e0b740cb05f3c7431d5cbd0d905342843170f4cecb3a40d6b356226d1a59eed","e6be2bb4dd460f5f87c5f800d053602fc4313df6c532b4391f386ff6798c7b1c","dc2d0f7dbdeacfdf23bae79172e6466b4d8f12ab7aabb2b1f81b35570af8a4fd","a2f946b56cb25a6fc5f1ad885741465c77d1ab83ffacd9bfc8e8c6009ed1e852","81836f148642680a6f5b0bb906aa286c4aaa40eb966a7c6c469fb77d20268fb6","f6c8e4f7f09c3b81d2a9cd1f677bf335f0d3f379c0c9dc9ed78b11cf2aa8bbdc"];for(let mask=1;mask<8;mask++){const model={...defaults,moonCasual:false,moonReal:false,moonHalftone:!!(mask&1),moonDiamond:!!(mask&2),moonChecker:!!(mask&4)};assert.equal(hashText(moonCraterMarkup(model)),patternBaselines[mask-1],'existing decorative pattern '+mask+' must be unchanged');}
  const wave=placements(clean({...defaults,mode:'wave',count:5,waveAmplitude:80,waveFrequency:1,waveOffset:0}));
  assert.ok(Math.abs(wave[1].y-80)<1e-8); assert.ok(Math.abs(wave[3].y+80)<1e-8);
  assert.equal(wave[0].x,-defaults.spread); assert.equal(wave[4].x,defaults.spread);
  const spiral=placements(clean({...defaults,mode:'spiral',count:9,layoutDecay:100}));
  assert.ok(Math.abs(Math.hypot(spiral[0].x,spiral[0].y)-defaults.layoutInner)<1e-8);
  assert.ok(Math.abs(Math.hypot(spiral[8].x,spiral[8].y)-defaults.spread)<1e-8);
  const normal=placements(clean({...defaults,mode:'spiral',count:9}));
  const reverse=placements(clean({...defaults,mode:'spiral',count:9,reverseSpiral:true}));
  assert.ok(Math.abs(normal[1].x+reverse[1].x)<1e-8);
  const fractal=placements(clean({...defaults,mode:'fractal',fractalBranches:4,fractalDepth:4}));
  assert.equal(fractal.length,341);
  const bounded=clean({...defaults,fractalDepth:999,fractalBranches:999});
  assert.equal(placements({...bounded,mode:'fractal'}).length,341);
  const child=placements(clean({...defaults,mode:'fractal',fractalBranches:2,fractalDepth:1}));
  assert.equal(child.length,3); assert.ok(Math.abs(child[1].scale/child[0].scale-.48)<1e-8);
  const packed=svg({...defaults,mode:'fractal',fractalBranches:4,fractalDepth:4});
  assert.equal((packed.match(/<use /g)||[]).length,341);
  assert.equal((packed.match(/id="motif/g)||[]).length,1);

  assert.ok(svg({...defaults,texture:'halftone'},{textures:true}).includes('<pattern'));
  assert.ok(!svg({...defaults,texture:'paper'},{textures:false}).includes('<pattern'));
  assert.ok(!svg({...defaults,texture:'canvas'},{textures:false}).includes('<pattern'));
  assert.ok(!svg({...defaults,mode:'fractal'},{guides:false}).includes('stroke-dasharray="3 4"'));
`, context);
console.log('PASS: lunar maria/rays, strong camera distance, XYZ floor placement, scene-wide clipping and unique references, full/phase/classic moons, 31 crater-style combinations, deterministic density/phase area/shadow/clip/export checks, connected ribbon folds 1–6, 26-shape XYZ projection and bounded perspective, neutral/JSON/reset/export regressions, legacy/new project roundtrip, pressure taper/tight-turn regression, dedicated morph boundaries/independence/paired-leaf regression, 234 shape/layout combinations, five line styles/all-shape pressure, previous/reset/undo, all-shape swirl, 3–16 arms and lily curves, paired/alternate leaves, cross terminals and split controls, 64-point stars, circular crescent arcs, pressure outlines and restoration, all shape controls, wave/spiral/fractal geometry, 341-node cap, shared references and export policies');

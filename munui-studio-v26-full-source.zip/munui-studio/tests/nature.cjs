const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const html=fs.readFileSync(path.join(__dirname,'../dist/index.html'),'utf8'),script=html.match(/<script>([\s\S]*)<\/script>/)[1].replace(/render\(\);\s*$/,'');
const context={assert,document:{getElementById(){return {style:{},addEventListener(){}}},addEventListener(){}},localStorage:{getItem(){return null}}};vm.createContext(context);vm.runInContext(script,context);
vm.runInContext(`
const names=['cloud','ocean','flame','maple','butterfly','eye'];
for(const shape of names){
 const base=clean({...defaults,shape,cloudLayers:3,butterflySymmetry:false});
 assert.equal(base.shape,shape);assert.ok(newShapeControls.call);assert.ok(shapeKeys[shape]);
 const g=geometry(base);assert.ok(g.includes('<path'));assert.ok(!/NaN|Infinity|undefined/.test(g));assert.equal(g,geometry(clean(JSON.parse(JSON.stringify(base)))));
 for(const [key,,min,max] of natureSpecs[shape]){
  assert.ok(shapeKeys[shape].includes(key));for(const value of [min,max]){const s=clean({...base,[key]:value});const out=geometry(s);assert.ok(!/NaN|Infinity|undefined/.test(out),shape+' '+key);if(value!==base[key])assert.notEqual(out,g,key+' changes geometry')}
  assert.ok(clean({...base,[key]:-9999})[key]>=min);assert.ok(clean({...base,[key]:9999})[key]<=max);
 }
 for(const key of newShapeKeys[shape])assert.ok(shapeKeys[shape].includes(key),key+' resets');
 const projected=svg({...base,viewX:55,viewY:-30,viewPerspective:90,viewDistance:300,swirlAngle:35,mode:'radial',count:3,itemScale:25});assert.ok(!/NaN|Infinity|undefined/.test(projected));
 const ink=source({...base,pressureOn:true,lineFeel:'ink'});assert.ok(!/NaN|Infinity|undefined/.test(ink));
}
for(const cloudLayers of [1,3,5])assert.ok(cloudGeometry({...defaults,cloudLayers}).includes('data-cloud-layers="'+cloudLayers+'"'));
for(const flag of ['oceanFoam','flameInner','mapleVeins','butterflyMarks','eyeHighlight']){const shape=names.find(k=>newShapeKeys[k].includes(flag));assert.notEqual(geometry({...defaults,shape,[flag]:true}),geometry({...defaults,shape,[flag]:false}));}
for(const mapleToothStyle of ['point','round','none'])assert.ok(!/NaN|Infinity/.test(mapleGeometry({...defaults,mapleToothStyle,mapleLobes:9,mapleTeeth:8,mapleToothDepth:10})));
for(const eyePupilStyle of ['round','slit','sparkle'])for(const eyeOpening of [15,80])for(const eyeGaze of [-60,0,60]){
 const s={...defaults,shape:'eye',eyePupilStyle,eyeOpening,eyeGaze,eyeIrisSize:48},raw=eyeGeometry(s),iris=raw.match(/data-nature-paint="iris" d="([^\"]+)"/)[1];
 for(const p of samplePath(iris).filter(p=>p.type!=='Z').map(p=>p.p))assert.ok(Math.abs(p[1])<=eyeOpening*(1-p[0]*p[0]/10000)+1e-5,'iris stays within eyelids');
}
const paired={...defaults,shape:'butterfly',butterflySymmetry:true};assert.equal(geometry(paired),geometry({...paired,butterflyLeftScale:40,butterflyRightScale:140}));assert.notEqual(geometry({...paired,butterflySymmetry:false}),geometry({...paired,butterflySymmetry:false,butterflyLeftScale:40}));
const invalid=clean({...defaults,shape:'maple',mapleToothStyle:'bad',eyePupilStyle:'bad',eyeIrisColor:'bad'});assert.equal(invalid.mapleToothStyle,'point');assert.equal(invalid.eyePupilStyle,'round');assert.equal(invalid.eyeIrisColor,defaults.eyeIrisColor);
`,context);
console.log('PASS: six nature shapes, dedicated field bounds/independence/reset/JSON, layers, details, maple teeth, butterfly symmetry, iris containment, pressure/XYZ/swirl/repeat');

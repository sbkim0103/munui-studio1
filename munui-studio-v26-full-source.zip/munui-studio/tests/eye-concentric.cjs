const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');const html=fs.readFileSync(path.join(__dirname,'../dist/index.html'),'utf8'),script=html.match(/<script>([\s\S]*)<\/script>/)[1].replace(/render\(\);\s*$/,'');const context={assert,document:{getElementById(){return {style:{},addEventListener(){}}},addEventListener(){}},localStorage:{getItem(){return null}}};vm.createContext(context);vm.runInContext(script,context);
vm.runInContext(`
for(const eyePolygonSides of [4,6,8,12,20])for(const eyeAngular of [0,50,100])for(const eyeGaze of [-60,0,60]){
 const s=clean({...defaults,shape:'eye',eyePolygonSides,eyeAngular,eyeGaze,eyeIrisSize:48}),R=eyeIrisRadius(s),outline=eyeOutlinePath(s);assert.ok(!/NaN|Infinity/.test(outline));if(eyeAngular===100)assert.equal((outline.match(/[ML]/g)||[]).length,eyePolygonSides);
 for(let i=0;i<128;i++){const a=i*Math.PI/64,x=eyeGaze+R*Math.cos(a),y=R*Math.sin(a);assert.ok(Math.abs(y)<=eyeEnvelope(s,x)+1e-5,'iris inside faceted eye');}
 for(const eyePupilStyle of ['round','slit','sparkle'])for(const eyePupilCount of [1,2,5,9])for(const eyePupilSpacing of [20,60,90]){
  const model={...s,eyePupilLayout:'concentric',eyePupilCount,eyePupilSpacing,eyePupilStyle},p=eyePupilPlacements(model,R),out=eyeGeometry(model);assert.equal(p.length,eyePupilCount);assert.equal((out.match(/data-eye-pupil=/g)||[]).length,eyePupilCount);
  for(let i=0;i<p.length;i++){assert.equal(p[i].x,eyeGaze);assert.equal(p[i].y,0);assert.ok(p[i].r+(p[i].width||0)/2<=R+1e-8);if(i){assert.ok(p[i].ring);assert.ok(p[i].r>p[i-1].r);assert.ok(p[i].width< p[i].r-p[i-1].r)}}
  assert.equal((out.match(/data-nature-paint="pupil"[^>]*fill="none"/g)||[]).length,eyePupilCount-1);assert.ok(!/NaN|Infinity|undefined/.test(out));assert.deepEqual(clean(JSON.parse(JSON.stringify(model))),model);
 }
}
const base={...defaults,shape:'eye',eyeAngular:100,eyePupilCount:4,eyePupilLayout:'concentric'};
for(const [k,v] of [['eyePolygonSides',6],['eyePupilSpacing',85],['eyePupilLineWidth',.3]])assert.notEqual(eyeGeometry(base),eyeGeometry({...base,[k]:v}));
for(const k of ['eyePolygonSides','eyePupilLineWidth'])assert.ok(shapeKeys.eye.includes(k));
assert.equal(clean({...base,eyePolygonSides:7}).eyePolygonSides,8);assert.equal(clean({...base,eyePolygonSides:999}).eyePolygonSides,20);assert.equal(clean({...base,eyePolygonSides:-1}).eyePolygonSides,4);
for(const eyePupilStyle of ['round','sparkle']){const out=svg({...base,eyePupilStyle,viewX:50,viewY:-30,swirlAngle:20,mode:'radial',count:3,itemScale:25});assert.ok(!/NaN|Infinity|undefined/.test(out));assert.ok(out.includes('data-eye-pupil='));}
`,context);console.log('PASS: 1,620 concentric combinations, exact shared center, ordered open rings, iris containment, 4–20 polygon sides, JSON/reset and XYZ/swirl/repeat');

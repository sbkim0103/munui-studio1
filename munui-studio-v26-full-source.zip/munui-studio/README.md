# 무늬 스튜디오 프로토타입

별도 패키지 설치가 없는 HTML · CSS · JavaScript 작도 도구입니다.

## 실행

`dist/index.html`을 브라우저로 열면 됩니다. 온라인 버전에서는 내보내기 단계의 실행 코드 다운로드 버튼으로도 같은 HTML을 받을 수 있습니다.

## 기능

- 하트를 포함한 13개 기본 도형과 문맥에 맞는 상세 구조 조절
- 하트의 갈라짐 · 볼륨 · 뾰족함, 잎의 휘어짐 · 폭 위치, 눈꽃 가지 각도 · 두께, 부채꼴 펼침 각도 등
- 형태 · 선 · 채우기 편집과 금색 · 홀로그램 색상 효과
- 종이 · 캔버스 · 하프톤 반복 무늬와 도형 또는 배경 적용
- 하프톤 점 크기 · 간격 · 각도 · 색 · 불투명도 조절
- 원본 · 방사형 · 선형 · 동심 · 회전 · 크기 변화 배열
- 원형 · 사각 테두리와 별 장식
- 물결형 배치와 진행 방향 정렬
- 나선 회전과 감김 · 반경 확장 · 개별 회전 · 점진 축소
- 자식 도형이 같은 규칙을 반복하는 재귀 프랙탈 확장
- PNG 출력, 하프톤을 유지하는 SVG 출력
- JSON 프로젝트 저장 · 불러오기, 브라우저 자동 저장, 되돌리기

## 현재 범위

종이와 캔버스는 실제 재질 스캔이 아닌 가벼운 벡터 반복 무늬이며 SVG 출력에서는 제외합니다. 하프톤은 균일한 점 패턴으로 SVG에도 유지되며 이미지의 명암을 자동으로 점 크기로 변환하는 기능은 아닙니다. 홀로그램과 금색은 정적 색상 효과입니다. 배열은 중심 위치를 기준으로 배치하므로 과도한 설정에서는 도형이 겹치거나 캔버스에 잘릴 수 있습니다. 경로 배치, 직접 그리기, 사용자 SVG 입력, 복수 원본, 스타일 라이브러리 저장은 아직 제공하지 않습니다.

프랙탈은 재귀 깊이 1~4단계, 자식 가지 2~4개로 최대 341개 도형을 배치합니다. SVG 정의를 재사용해 중복 경로와 파일 크기 증가를 줄입니다. 깊이는 루트 아래 자식 세대 수이며 루트도 결과에 포함됩니다. 기존 버전의 JSON 프로젝트는 추가 값을 기본값으로 보완해 읽습니다.

브라우저 자동 저장은 해당 브라우저에 한정되며 프로젝트 JSON 파일을 별도로 저장하면 다른 환경에서 다시 편집할 수 있습니다. 로컬 HTML의 코드 다운로드는 브라우저 보안 설정에 따라 제한될 수 있지만 작도와 파일 내보내기는 사용할 수 있습니다.

## 구조

현재는 `dist/index.html` 하나에 스타일과 실행 코드가 들어 있습니다. 도형 수학은 `geometry`, 배열 좌표는 `placements`, SVG 표현은 `source`와 `scene` 및 `svg`, 상태 정규화는 `clean`, 단계별 화면은 `render`에 있습니다. 기능 확장 시 이 단위로 파일을 분리할 수 있습니다.

## 검증

`node tests/geometry.cjs`로 기존 프로젝트 호환성, 117개 도형 및 배치 조합, 도형별 변형 범위, 물결과 나선 좌표, 재귀 개수 제한과 SVG 참조 및 출력 정책을 확인합니다.

## 도형 라이브러리 · 필압 확장

- 기본 도형 19종: 클로버, 톱니 잎, 갈래 잎, 고사리 잎, 원호, 직선 추가.
- 도형별 구조 설정 및 초기화, 기존 v1 파일 기본값 보충.
- 소용돌이·S곡선·물결선·원호·직선: 시작/중간/끝 굵기, 최대 굵기 위치, 부드러움.
- 필압은 경로 길이 기준 벡터 면 윤곽으로 출력. 필압 활성화 중 점선 미적용.
- 검증: 171개 도형/배치 조합, 구조 옵션 경계값, 필압 윤곽과 프로젝트 복원.

## 잎 배열 · 십자 끝 장식 · 달 도형

- 렌즈 잎/톱니 잎/갈래 잎: 한 장, 마주나기, 어긋나기. 쌍 개수, 줄기 간격, 좌우 크기, 각도, 어긋남과 줄기 표시.
- 고사리: 좌우 크기와 어긋남.
- 십자: 원형/두 갈래/세 갈래/마름모, 네 끝 개별 선택. 연결부는 하나의 면 윤곽.
- 초승달: 두께와 방향. 반원: 높이와 밑변 곡률. 총 21종.
- 기존 v1 프로젝트는 한 장/장식 없음으로 복원. PNG/SVG와 프로젝트 JSON에 반영.

## 끝 장식 세분화 및 초승달 재설계

- 십자 다중 갈래(2–7), 백합형, V/U 골, 끝 너비, 가운데 길이, 외곽 휘어짐. 끝 종류는 개별 선택, 세부 수치는 공통.
- 별 꼭짓점 3–64개. 다각형/눈꽃은 기존 16개 제한 유지.
- 초승달의 두 경계를 교점이 같은 정확한 원호로 재설계. 두께/양 끝 벌어짐 각도/방향 조절. 기존 프로젝트의 초승달 외형은 새 작도 방식으로 갱신됨.

## 다중 팔과 원본 나선 변형

- 십자 팔 3–16개. 4팔은 기존 길이/오프셋 보존, 다른 수는 균일 방사형. 팔별 끝 종류 선택, 간격에 맞춰 두께/장식 너비 제한.
- 물방울/부채꼴/튤립 끝 장식. 백합 전용 cubic 곡선: 볼륨/측면 끝 방향/목 너비/중앙 길이/골 깊이.
- 모든 도형에 나선 변형 ±360°, 집중도 0.3–3. 골 회전 유지. 원본 작도 좌표의 중심 거리로 비트는 방식. 0°에서는 기존 벡터 곡선 유지, 활성화 시 촘촘한 선분의 벡터 경로로 변환해 SVG/PNG에 반영.
- 기존 v1 파일은 4팔, 나선 변형 0으로 복원. 백합형 외형은 개선된 곡선으로 갱신.

## 명칭 · 작업 이동 · 선 느낌

- 화면/탭/호스팅 타이틀: 무늬 스튜디오. 기존 URL 유지.
- 상단 이전 단계: 현재 설정 보존. 처음부터: 전체 기본값 복귀, undo로 복구.
- 모든 원본 도형 외곽선에 수치 필압. 닫힌 경로는 시작/끝 평균 두께로 이음새 연결.
- 먹선/목탄/연필/오일파스텔: 고정 시드 입자 및 수학적 외곽 흔들림을 사용한 시험 표현. 색/굵기/입자/강도 조절. 생성형 이미지 모델, 학습 이미지, 외부 자산 없음.
- 기본 선 굵기 최대 24px. 2px 이하에서 질감을 처음 고르면 권장 굵기 적용. 필압/질감 활성화 중 점선과 native join 옵션 숨김.
- PNG 및 SVG에 필압/선 질감 포함. 필압 윤곽은 벡터 면, 질감은 벡터 반복 패턴. 기존 프로젝트 파일은 기본 벡터선으로 로드.
- 검증: 전체 도형×5가지 선 느낌/필압, 닫힌 고리 경로, 참조 무결성, 저장복원, 이전/초기화/undo, 브라우저 PNG 생성 및 SVG 저장 안내 확인.

## 필압 끝단 교차 보정

- 단일 오프셋 윤곽의 자기 교차를 제거하고, 구간의 외접 접선과 원형 연결부를 양의 winding으로 합성.
- 급한 곡률/뾰족한 모서리에서 겹침이 evenodd 빈 구멍으로 반전되지 않도록 nonzero 채움 적용. 실제 경로가 겹치는 구간은 선이 자연스럽게 합쳐짐.
- 0 굵기 끝에서는 질감 흔들림도 0으로 수렴, 중복점 제거, 길이 0 구간/완전히 덮이는 접선 구간 처리.
- 회귀 검증: 급회전 경로의 중심선 커버리지, 조각 winding 일관성, 모든 선 스타일의 0 끝단, 24px/300% 필압, 잎·초승달·별·십자·소용돌이·S 곡선.

## 도형 전용 실루엣 변형

- 21종 각각에 필요한 변형만 표시. 1단계의 접이식 전용 그룹: 굽힘(위치), 위아래 폭, 단일 도형 좌우 비대칭, 끝 파임(개수/펼침), 가장자리 물결(개수/위상), 허리 조임/부풀림(위치), 기울임. 초승달에는 위/아래 끝 길이.
- 렌즈 잎의 기존 휘어짐, 톱니/갈래 잎의 기존 가장자리 구조는 유지. 잎 쌍은 각 잎에 변형을 한 번만 적용한 뒤 줄기에 배열.
- 도형별 이름 공간으로 값을 분리, 프로젝트 JSON/자동저장/undo/전용 초기화에 포함. 기존 파일은 모두 중립값으로 보충되어 이전 외형 유지.
- 전용 변형 후 선/필압/질감, 나선 비틀기, 반복 배열 순서로 적용. 중립값에서는 기존 곡선 경로 그대로 사용.
- 검사: 전체 전용 필드 경계값/기하 변화, 도형 간 독립성, 왕복 저장복원, 잎 쌍 단일 적용, 필압+나선 조합 및 기존 끝단 회귀 검사.

## 화살표 · 방패 · 리본

- 24개 기본 도형. 화살표는 머리/몸통/꼬리/방향 그룹에서 편집. 삼각/열린 꺾쇠/마름모/창끝/둥근 머리, 꼬리 없음/일자/원형/깃털/갈라짐 및 양방향. 머리는 몸통 접선을 따르며 방향 보정 지원. 연속 면 윤곽으로 파츠 접합부의 중복 외곽선 제거. 몸통 굽힘이 강하면 두께를 최소 곡률 반경에 맞춰 제한.
- 방패: 어깨 너비/윗변 곡률/어깨 길이/아래 길이/옆 볼륨/뾰족·둥근·평평한 바닥.
- 리본: 띠 너비/중앙 처짐/접힘/양쪽 꼬리 표시·길이/일자·갈라짐·뾰족한 끝/접힘선 표시.
- 세 도형 모두 전용 변형, 스타일, 필압, 반복배치, 프로젝트 저장·복원 및 초기화에 연결.
- 검증: 216 도형/배치 조합, 화살표 50가지 머리/꼬리/양방향 조합, 방패 바닥/리본 꼬리 조합과 필압·질감·나선 연동.

Arrow heads support inward/outward curved wings and curvature position while preserving tip/neck anchors. Ribbon tails support wave amplitude/cycles/phase, static wind direction/strength and tension, and left/right vertical offset. One to five ribbon tiers have gap, horizontal step and progressive scale controls, fitted as one motif. New controls persist in v1 projects and participate in per-shape reset.

Folded ribbon construction now separates back tails, diagonal return folds and the front face, rendered in paint order. Front width, fold depth/offset and optional fold shading are independent of multi-tier stacking. The reference-layout button applies a long flat banner with lowered swallowtails and light edge damage. Deterministic vector weathering supports chips/narrow tears/ragged tears, depth, density, roughness, seed and front/tail targeting; continuous ribbons remain selectable.

Ribbon fold count (1–6 per side) extends a single banner through connected stepped panels with terminal tails only on the final fold; multi-tier repetition remains separate. All 24 shapes support XYZ plane rotation and adjustable perspective, applied after morph/pressure/swirl and before repeated layout. The projected vector geometry persists in PNG/SVG and project JSON; zero angles preserve original markup and front-view reset restores it.

The moon preset supports a full disc, a continuous 1–100% illuminated silhouette and legacy circular crescents. Five independently enabled surface styles (casual craters, shaded irregular rims, halftone dots, diamond sparkles, checker tiles) share deterministic packed positions with density, size, opacity, color and seed controls. Independent moon shadows support coverage, opacity, direction and color. Surface vectors follow dedicated morphs, clip to the moon silhouette, and retain clipping through swirl/XYZ/SVG export. Legacy v1 crescent files without moon fields keep their classic silhouette with surface marks disabled.

Lunar maria now form large irregular connected tonal regions, with graphic and layered-gray presets, coverage/edge roughness controls, sparse impact craters and adjustable ejecta rays. The perspective camera uses explicit distance, XYZ world placement and near-plane clipping instead of automatic distance compensation. Whole-composition projection puts repeats and frames on one shared plane; per-motif projection remains selectable. A camera-matched numbered XYZ floor grid is preview-only.

Arrowheads now include pointed heart and heraldic fleur-de-lis silhouettes, with cleft, lobe spread/curl and binding width controls. Curved feather tails support up to nine pairs, 90 px length, spacing distribution, swept vanes, taper, notch depth, left/right staggering and pointed/rounded/flat tips. New flower and sun presets expose dedicated petal/layer/center and ray/core controls, use ordered vector part rendering, and support the existing morph, pressure, swirl, XYZ, repeat and export workflows.

Impact craters are a separate vector layer with explicit count, size, clustering density, global XY/rotation, rim irregularity, inner-wall shading, rim highlight and lighting controls. Number-selected per-crater XY offsets are sanitized and preserved in v1 JSON without truncation. Density changes clustering rather than count. Existing sparkle/halftone/checker renderers and seven combinations are checked against pre-change hashes; users can order those patterns above or below craters. Edit selection guides remain preview-only.

Flower centers now support circle, square, triangle, star (3–16 points with adjustable inner ratio), and polygon (3–16 sides) silhouettes, size and rotation. Grid, radial lines, concentric rings, and dots are independent combinable vector layers; line counts, dot density/size, grid or sunflower spiral distribution, rotation, color, width, and opacity are editable. Analytic segment clipping handles concave star notches without SVG clip IDs; dots fit entirely inside the center. Pattern strokes retain their dedicated width/color when the petal outline is disabled and through morph, swirl, XYZ, repeat and export.

Petals independently expose count (3–48), overlap (0–100%), layers (1–8), length (10–140%), width, bend and round/pointed/notched/flat tips. Layer shrink and rotation remain adjustable. Neutral new options preserve previous flower paths. `node tests/flower.cjs` checks 75 center/pattern combinations, concave clipping, neutral compatibility, independent controls, reset/JSON and projected SVG output.

Six deterministic nature presets extend the library to 32 shapes: cloud (lobes, curvature, height, 1–5 layers and spacing), filled ocean wave (amplitude, 0.5–5 cycles, phase, thickness, crest asymmetry and inner line), flame (1–7 tongues, length, width, split depth, bend and ember), maple leaf (3–9 lobes, notch depth, spread, tooth count/depth and pointed/rounded/plain edges, stem and veins), butterfly (upper/lower wing ratios, length, spread, body, antennae, optional per-side scaling and markings), and eye (opening, tilt, iris size/color, round/slit/sparkle-diamond pupils, gaze, angular outline and highlight). Iris size is conservatively limited by the eyelid envelope as gaze/opening change. Each preset participates in shape reset, independent morph namespaces, ordered vector painting, pressure/line styles, swirl, XYZ, repetition, PNG/SVG and v1 JSON. `node tests/nature.cjs` verifies parameter boundaries/independence, per-shape resets, JSON, cloud layer count, butterfly symmetry, iris containment, optional details and transformed exports.

Eye refinement removes eyelashes and migrates legacy star pupils to a four-tip concave sparkle diamond. Outline angularity interpolates between the original almond and a selected 4–20-sided polygon, with the iris constrained to the selected envelope. One to nine pupils support linear/radial placement, spacing and rotation; pupil radius is bounded by iris clearance and neighbor separation. All controls persist/reset with the eye. `node tests/eye.cjs` checks angular iris containment, pupil count/containment/non-overlap, legacy migration and transformed exports.

Concentric pupil expansion keeps one filled central pupil and draws successively larger open outlines at the same center, with count, radial spread and line width controls. Round, slit and sparkle silhouettes share this behavior; linear and orbital placement remain available. Polygon side count (even 4–20) and continuous faceting control are independent, and iris fitting uses that exact piecewise envelope. `node tests/eye-concentric.cjs` covers 1,620 concentric combinations, ring ordering/containment, exact polygon vertex counts, reset/JSON and transformed vector exports.

Eye expressions add independent smile-arc (-100–100%) and closure (0–100%) controls with open/smiling/closed shortcuts. Partial closure uses a vector eyelid clip while retaining the original iris and pupil size, so they are occluded rather than compressed. Full closure omits iris/pupil geometry and produces one open curved lid path that supports pressure and line styles; when outlines are disabled its line uses the fill color. Expression clips follow morph/swirl/XYZ, have unique per-instance IDs under whole-scene projection, and remain in SVG/PNG. Neutral expression values preserve earlier geometry. `node tests/eye-expression.cjs` checks 60 expression combinations, lid bounds, complete closure, clip references and transformed repeats.

The flame uses the user's reference as a structural base: one dominant tongue above a rounded body and optional nested closed ember surfaces. Dedicated flame colors and palette controls have been removed; all parts use common fill/stroke styling. Multi-tongue geometry gives the primary tongue more horizontal room and reduces secondary heights toward the outside. Notch depth is bounded by local tongue spacing; valley handles share a horizontal tangent, and tip handles open diagonally to prevent needle-like spires. Inset crown positions scale inward without collapsing adjacent tips. One to seven tongues, auxiliary height, depth, curl, length/width, lean and base volume remain editable. The basic-form button restores structural defaults and visible outlines. Nested surfaces retain clip IDs through morph/swirl/XYZ/repeat/export. `node tests/flame.cjs` checks extreme contour self-intersection, ordered valleys, common styling, clip references, legacy color removal and JSON/reset.

Flame inner-line correction: mantle, ember and core now derive successively from the outer flame contour by an anisotropic inward offset, so all layers follow tongue count, notch depth, curl, side height and bend. Offset loops are cleaned and each candidate is checked for containment/clearance before rendering. Inner stroke contours are complete closed paths, replacing the fixed teardrops and clipping-based joins. Width/height/core controls tune the inset rather than a separate motif. `node tests/flame-layers.cjs` verifies 48 nested layer combinations, no self crossings, parent/child edge containment, control linkage and transformed exports.

Cloud redesign follows the supplied simple outline (dominant offset upper lobe, smaller neighbor, round shoulders and flat base), with basic/puffy/wide/towering shape-only presets. Upper lobe count, curve depth, height, peak position, 1–5 connected rows/gap, lower scallops/count, thin lateral wisps and deterministic size variation/seed are independent. An implicit ellipse/capsule union is traced with marching squares into one closed outer contour; internal overlaps do not produce seams. Row connectors keep raised puffs attached, and a blended lower envelope transitions between the flat base and lower scallops. `node tests/cloud.cjs` checks 36 combinations, complete contours, reference base, growth, wisps, reset/JSON and transformed export.

Construction previews (stage 1) now use neutral white/black/gray for every shape without overwriting saved style values; construction color inputs are hidden. Eye iris, flower detail and moon detail colors are available in stage 2's fill tab. Shape presets do not assign palettes. The cloud test checks neutral source output and no construction color pickers across all 32 shapes, and verifies later style values remain available.
